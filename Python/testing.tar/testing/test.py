import Readings

print ( Luminosity , Humidity , Temperature )

