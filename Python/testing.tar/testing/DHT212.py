
#!/usr/bin/env python

import pigpio
import DHT22
from time import sleep

pi = pigpio.pi()

dht22 = DHT22.sensor(pi,27)
dht22.trigger()

sleepTime = 3

def readDHT22temp ():
    dht22.trigger()
    
    temperature = '%.2f' %(dht22.temperature())

    sleep (sleepTime)

    return (temperature)

def readDHT22hum ():
    dht22.trigger()
    
    humidity = '%.2f' %(dht22.humidity())

    sleep (sleepTime)

    return (humidity)



