from gpiozero import LightSensor

def luminosityC():

    ldr1 = LightSensor(4)
    ldr2 = LightSensor(8)
    ldr3 = LightSensor(9)
    ldr4 = LightSensor(10)

    luminosity = (ldr1.value + ldr2.value + ldr3.value + ldr4.value)/4

    return (luminosity)
 
