import PID
import time
import ldr

ldrp = PID.PID(0.1, 1, 1)

ldrp.SetPoint=20
ldrp.setSampleTime(1)

while True :
    
    lfeedback = 10
    
    ldrp.update(lfeedback)

    loutput = ldrp.output

    print (loutput,lfeedback)


