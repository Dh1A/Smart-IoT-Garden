import DHT212
import ldr
from time import sleep

while True :
    
    Luminosity = ldr.luminosityC()
    Temperature = DHT212.readDHT22temp ()
    Humidity = DHT212.readDHT22hum ()

    print(Humidity,Temperature)    



